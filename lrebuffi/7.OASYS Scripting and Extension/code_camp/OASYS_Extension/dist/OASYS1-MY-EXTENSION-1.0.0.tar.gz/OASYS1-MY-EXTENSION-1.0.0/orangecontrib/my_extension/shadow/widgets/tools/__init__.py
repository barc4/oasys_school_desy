
# Category description for the widget registry

NAME = "My Shadow Tools"

DESCRIPTION = "Widgets for My Shadow"

BACKGROUND = "#FACC2E"

ICON = "icons/tools.png"

PRIORITY = 100.1
